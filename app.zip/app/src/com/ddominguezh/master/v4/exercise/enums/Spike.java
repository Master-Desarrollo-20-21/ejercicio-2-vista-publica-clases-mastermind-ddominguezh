package com.ddominguezh.master.v4.exercise.enums;

public enum Spike {
	WHITE,
	BLACK,
}
