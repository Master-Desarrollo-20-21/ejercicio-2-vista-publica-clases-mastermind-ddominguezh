package com.ddominguezh.master.v4.exercise.exception;

public class LengthException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1504572363951524687L;
	public LengthException() {
		super("Wrong proposed combination length");
	}
}
