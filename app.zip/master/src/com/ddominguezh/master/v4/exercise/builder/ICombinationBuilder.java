package com.ddominguezh.master.v4.exercise.builder;

import com.ddominguezh.master.v4.exercise.entity.Combination;

public interface ICombinationBuilder {

	Combination build();
	
}
